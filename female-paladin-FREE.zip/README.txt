Female Paladin
Free: 274 animation frames: Idle Breathing, Walk and Sword Slash Horizontal, all in 8 directions. These same frames are included in Full. No art boards.
Commercial and non-commercial use and modifications allowed. Credit "elie automata". Distribution within finished projects allowed. No standalone resale, sharing or redistribution of original or modified assets.